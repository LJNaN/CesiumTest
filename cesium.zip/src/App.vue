<script setup>
import Scene from './views/scene.vue'
</script>

<template>
  <Scene />
</template>

<style scoped>
</style>
